```markdown
# Product Requirements Document (PRD) - Real-time Trade Simulator

**Version: 1.0**
**Date: May 19, 2025**

---

## 1. Executive Summary

This document outlines the requirements for a high-performance, real-time trade simulator. The simulator will connect to live Level 2 (L2) orderbook data via a WebSocket feed (specifically for OKX BTC-USDT-SWAP initially), process this data in real-time, and provide estimates for key transaction costs and market impact metrics for a simulated market order of a specified quantity. The goal is to give users insight into the potential execution costs and characteristics *before* placing a trade, leveraging quantitative models and real-time market depth information. The system is designed for speed and accuracy, processing data faster than it is received and presenting results via a simple user interface.

---

## 2. Product Vision

The vision for the Real-time Trade Simulator is to become a foundational tool for understanding the micro-structure costs of executing trades in volatile cryptocurrency markets. By leveraging high-fidelity, real-time L2 orderbook data and established quantitative models, the simulator will provide users with actionable insights into expected slippage, fees, market impact, and the nature of order execution (maker/taker split).

The primary purpose is to empower traders and quantitative analysts to make more informed decisions regarding trade execution strategy. It aims to reduce unexpected costs by providing pre-trade estimates based on current market conditions.

Target Users:
*   **Quantitative Traders:** Need precise estimates of execution costs for algorithmic trading strategy development and backtesting (though this version is forward-looking simulation).
*   **Execution Desks:** Require real-time insights to optimize large order placement and minimize transaction costs.
*   **Individual Traders:** Want to understand the true cost of placing market orders beyond just the stated fee percentage.

Business Goals:
*   Demonstrate capability in building high-performance, low-latency market data processing systems.
*   Prove proficiency in implementing and applying quantitative finance models (Almgren-Chriss, Regression).
*   Potentially serve as a module or proof-of-concept for a larger trading platform or execution analytics suite.
*   Provide a tool that adds tangible value by improving transparency around trade execution costs.

---

## 3. User Personas

**Persona 1: Quant Analyst "Alex"**

*   **Background:** Works at a small quantitative trading firm specializing in cryptocurrency. Has a strong technical and mathematical background.
*   **Goals:** Develop and test execution algorithms, minimize transaction costs for strategies, understand market impact and slippage characteristics of different venues and assets.
*   **Pain Points:** Lack of tools to accurately estimate real-time execution costs *before* trading; difficulty processing high-volume, real-time L2 data; need for quick iteration and analysis.
*   **Needs from Product:** Accurate, real-time cost estimates (slippage, fees, market impact); ability to configure trade parameters; insight into how orderbook depth affects costs; performance metrics of the simulator itself.

**Persona 2: Execution Trader "Sam"**

*   **Background:** Manages order flow for a proprietary trading desk or institutional client base. Focuses on efficient execution of large blocks.
*   **Goals:** Achieve best execution price, minimize slippage and market impact, understand the true cost of liquidity uptake.
*   **Pain Points:** Slippage exceeding expectations, unclear market impact of large orders, need for quick decisions based on current market depth.
*   **Needs from Product:** Simple, intuitive interface showing key cost metrics instantly; reliable estimates based on current market conditions; confidence in the underlying models and data processing.

---

## 4. Feature Specifications

This section details the core features based on the assignment requirements.

### Feature 4.1: Real-time Market Data Ingestion

*   **Description:** The system must connect to the specified WebSocket endpoint for OKX BTC-USDT-SWAP L2 orderbook data, process the incoming stream, and maintain a current representation of the orderbook.
*   **User Story:** As a user, I want the simulator to connect to the live market data feed and constantly update its view of the orderbook so that cost estimations are based on current market conditions.
*   **Acceptance Criteria:**
    *   System successfully establishes a WebSocket connection to `wss://ws.gomarket-cpp.goquant.io/ws/l2-orderbook/okx/BTC-USDT-SWAP`.
    *   System correctly parses incoming JSON messages according to the specified format.
    *   System maintains an up-to-date internal representation of the BTC-USDT-SWAP L2 orderbook (bids and asks).
    *   The data processing pipeline (ingestion, parsing, orderbook update) operates faster than the incoming data stream.
    *   Handles minor network interruptions gracefully (e.g., attempts to reconnect).
*   **Edge Cases:**
    *   WebSocket connection failure on startup or during operation.
    *   Receipt of malformed or unexpected data formats.
    *   Extremely high message volume potentially overwhelming processing capacity.
    *   Significant clock drift between the system and the data source timestamp.
    *   Empty bids or asks arrays in the incoming data.

### Feature 4.2: Input Configuration UI

*   **Description:** A user interface element (left panel) allowing users to define parameters for the simulated trade.
*   **User Story:** As a user, I want to easily configure the details of the hypothetical trade (asset, quantity, fees, etc.) so the simulator can provide relevant cost estimates.
*   **Acceptance Criteria:**
    *   A dedicated section in the UI (left panel) contains input fields/controls for:
        *   Exchange (Pre-filled/Fixed: OKX)
        *   Spot Asset (Pre-filled/Fixed: BTC-USDT-SWAP, based on the provided feed. *Note: Assignment mentions 'Spot Asset' and 'Any available', but feed is SWAP. PRD focuses on the provided feed.*)
        *   Order Type (Pre-filled/Fixed: market)
        *   Quantity (Input field, approx. 100 USD equivalent - should be input as base asset quantity or value, clarify units. Inputting value in USD and converting is more user-friendly. Let's specify input in USD value, ~100 USD target). *Refinement:* Input should probably be in terms of the *base* asset quantity or equivalent value in the *quote* asset (USDT). Let's specify input as 'Quantity (USDT equivalent)' or 'Quantity (BTC)' with validation. Inputting ~100 USDT equivalent is clearer based on prompt.
        *   Volatility (Input field, market parameter - needs definition, e.g., annualized volatility or volatility over a short period used in models). *Refinement:* Volatility is usually an input for Almgren-Chriss. The PRD should specify *how* this input is expected (e.g., decimal representing daily vol, annualized vol, etc.). Let's assume a simple decimal input representing historical or assumed volatility relevant to the time horizon.
        *   Fee Tier (Input selection/field based on OKX tiers, e.g., Tier 1, Tier 2, or a numerical value representing taker fee rate). *Refinement:* Inputting a fee tier name (like "Tier 1") is user-friendly, requiring internal mapping to a fee rate. Inputting the actual taker fee rate (%) is more direct for calculation. Let's specify input as Taker Fee Rate (%).
    *   Input values are validated (e.g., quantity > 0, volatility >= 0, fee rate >= 0).
    *   Configured parameters are stored internally and accessible by the calculation models.
*   **Edge Cases:**
    *   User enters non-numeric values for quantity, volatility, or fee rate.
    *   User enters zero or negative quantity.

### Feature 4.3: Output Display UI

*   **Description:** A user interface element (right panel) displaying the calculated transaction costs and performance metrics in real-time.
*   **User Story:** As a user, I want to see the estimated costs and system performance metrics updated continuously as new market data arrives.
*   **Acceptance Criteria:**
    *   A dedicated section in the UI (right panel) displays output values clearly labeled for:
        *   Expected Slippage (Numeric value, e.g., in USDT or as a percentage of trade value)
        *   Expected Fees (Numeric value, e.g., in USDT or as a percentage)
        *   Expected Market Impact (Numeric value, e.g., in USDT or as a percentage)
        *   Net Cost (Numeric value, e.g., in USDT or as a percentage - Sum of Slippage, Fees, Market Impact)
        *   Maker/Taker proportion (Numeric value, e.g., as a decimal or percentage indicating the predicted taker proportion)
        *   Internal Latency (Numeric value, e.g., in microseconds or milliseconds, measured per tick processing)
    *   Output values update in near real-time as new market data ticks are processed.
    *   Units for output values are clearly indicated.
*   **Edge Cases:**
    *   Calculations fail or result in non-finite numbers (e.g., division by zero), outputs should display an error or N/A.
    *   Market data stops, outputs should indicate data stagnation or connection issue.
    *   Outputs not updating due to processing bottlenecks (handled by Performance feature).

### Feature 4.4: Expected Slippage Calculation

*   **Description:** Calculation of expected slippage based on the current orderbook depth and the simulated trade quantity, using a linear or quantile regression model.
*   **User Story:** As a user, I want an estimate of how much the execution price might deviate from the midpoint or best bid/ask due to the size of my market order hitting available liquidity.
*   **Acceptance Criteria:**
    *   A slippage model is implemented using either linear or quantile regression.
    *   The model takes the simulated trade quantity and current L2 orderbook data as input.
    *   The output is a numerical estimate of expected slippage for the specified trade.
    *   The calculation is performed efficiently upon receiving a new market data tick.
*   **Edge Cases:**
    *   Orderbook is very shallow or empty on one side.
    *   Regression model not yet trained or trained on insufficient data (requires initial data buffering or a fallback). *Refinement:* For the assignment, the model might be simplified or based on the instant orderbook profile rather than historical regression across ticks, unless historical data collection/training is explicitly in scope (it isn't specified, so focus on using the *current* tick's orderbook depth for calculation, potentially informing a simple model). Let's assume the regression *concept* applies to fitting a curve to the *current* orderbook depth profile.
    *   Trade quantity exceeds available liquidity far from the current price.

### Feature 4.5: Expected Fees Calculation

*   **Description:** Calculation of expected trading fees based on the simulated trade quantity, asset price, and the user-defined fee tier/rate.
*   **User Story:** As a user, I want to know the estimated fees I would pay for the simulated market trade based on my account tier.
*   **Acceptance Criteria:**
    *   A rule-based fee model is implemented.
    *   The model takes the simulated trade quantity, current asset price (derived from the orderbook, e.g., midpoint or best bid/ask), and the user-input taker fee rate as input.
    *   Fees are calculated (e.g., Quantity * Price * Taker Fee Rate).
    *   The output is a numerical estimate of expected fees.
    *   The calculation is performed efficiently upon receiving a new market data tick.
*   **Edge Cases:**
    *   Trade quantity is zero.
    *   Asset price cannot be determined from the orderbook (e.g., empty orderbook).

### Feature 4.6: Expected Market Impact Calculation (Almgren-Chriss)

*   **Description:** Calculation of expected market impact using the Almgren-Chriss model, based on trade quantity, volatility, and potentially market liquidity/depth parameters derived from the L2 data.
*   **User Story:** As a user, I want to understand the estimated price movement my trade might cause, beyond just hitting existing bids/asks, based on a standard financial model.
*   **Accept criteria:**
    *   The Almgren-Chriss market impact model is implemented.
    *   The model requires specific parameters (e.g., trade size, volatility, market specific parameters like liquidity/resilience). *Refinement:* The model input parameters need clarification. Almgren-Chriss typically involves a trading *schedule* over time, and parameters representing permanent and temporary market impact, often calibrated historically. For a *single market order simulation* based on *one tick*, a simplified interpretation is needed. The prompt link suggests understanding the model. For this assignment's context, the model should likely be applied to estimate the *total* impact of executing the full quantity *instantaneously* or over a very short, implicit time horizon, using the provided volatility input and orderbook data for liquidity/temporary impact estimation. The implementation should define and document its specific interpretation and parameterization of Almgren-Chriss for a single market order simulation.
    *   The calculation utilizes the user-input volatility and current L2 orderbook data (to derive parameters like market depth or volume).
    *   The output is a numerical estimate of expected market impact.
    *   The calculation is performed efficiently upon receiving a new market data tick.
*   **Edge Cases:**
    *   Trade quantity is zero.
    *   Volatility parameter is zero (may cause model issues depending on implementation).
    *   Orderbook data is insufficient to derive necessary model parameters.
    *   Model parameters are highly sensitive to small changes in orderbook state.

### Feature 4.7: Net Cost Calculation

*   **Description:** Summation of the three calculated cost components: Expected Slippage, Expected Fees, and Expected Market Impact.
*   **User Story:** As a user, I want to see the total estimated cost of my simulated trade at a glance.
*   **Acceptance Criteria:**
    *   Net Cost is calculated as the sum of Expected Slippage + Expected Fees + Expected Market Impact.
    *   The output is a numerical value representing the total estimated cost.
    *   The calculation is performed efficiently after the individual cost components are calculated for a given tick.
*   **Edge Cases:**
    *   Any of the individual cost components are invalid (e.g., NaN, error). The Net Cost should reflect this (e.g., display N/A or error).

### Feature 4.8: Maker/Taker Proportion Prediction

*   **Description:** Prediction of the proportion of the simulated market order quantity that would execute against maker vs. taker volume, using a logistic regression model.
*   **User Story:** As a user, I want to understand the likely execution type of my market order (how much fills against passive orders vs. requires crossing the spread further).
*   **Acceptance Criteria:**
    *   A logistic regression model is implemented to predict the maker/taker fill proportion for a market order.
    *   The model takes the simulated trade quantity and features derived from the current L2 orderbook data (e.g., depth at different levels, spread) as input.
    *   The output is a numerical value (e.g., between 0 and 1, or 0% and 100%) representing the predicted proportion that will execute as *taker* volume (as market orders consume passive maker liquidity). *Refinement:* Clarify which proportion is predicted (taker or maker). Predicting taker proportion is common for market orders. Let's predict Taker Proportion.
    *   The calculation is performed efficiently upon receiving a new market data tick.
*   **Edge Cases:**
    *   Trade quantity is zero.
    *   Orderbook data is insufficient to derive necessary model features.
    *   Model prediction results in an illogical value (e.g., > 1 or < 0).

### Feature 4.9: Internal Latency Measurement

*   **Description:** Measurement and display of the processing time required for the system to handle a single market data tick and update calculations.
*   **User Story:** As a user (or developer/QA), I want to monitor the performance of the simulator to ensure it is processing data quickly enough.
*   **Acceptance Criteria:**
    *   The system measures the time elapsed from receiving a market data tick to completing all associated calculations and preparing output values.
    *   This latency metric is displayed in the UI (right panel).
    *   The measurement is performed for each processed tick.
*   **Edge Cases:**
    *   System performance degrades significantly, leading to high latency readings.
    *   Measurement mechanism itself introduces significant overhead.

### Feature 4.10: System Performance and Stability

*   **Description:** Core non-functional requirements ensuring the system is fast, reliable, and maintainable.
*   **User Story:** As a user, I want a reliable and fast simulator that doesn't crash or fall behind the market data stream.
*   **Acceptance Criteria:**
    *   The system consistently processes market data ticks faster than the average arrival rate of the stream.
    *   Implemented in either Python or C++ with a focus on performance for critical real-time loops.
    *   Proper error handling is implemented to catch exceptions and prevent crashes (e.g., invalid calculations, network issues).
    *   Logging is implemented to record errors, warnings, and potentially key operational events (e.g., connection status, tick processing time).
    *   Codebase adheres to clean coding principles, is well-structured, and maintainable.
    *   Models and algorithms used are documented internally (code comments) and externally (separate documentation deliverable).
*   **Edge Cases:**
    *   Sustained periods of extremely high market data velocity.
    *   Resource constraints on the host machine (CPU, memory).
    *   Unhandled exceptions crashing the application.
    *   Log file growing excessively large.

---

## 5. Technical Requirements

*   **API Integration:**
    *   Connect to the provided WebSocket endpoint `wss://ws.gomarket-cpp.goquant.io/ws/l2-orderbook/okx/BTC-USDT-SWAP`.
    *   Handle WebSocket connection lifecycle (connect, disconnect, reconnect attempts).
    *   Parse JSON messages matching the specified L2 orderbook format.
*   **Data Processing:**
    *   Efficient real-time processing of incoming L2 ticks.
    *   Maintain a live, accurate, and efficiently queryable representation of the BTC-USDT-SWAP L2 orderbook in memory. Data structures must allow fast lookups and updates (e.g., sorted dictionaries, skip lists, or specialized orderbook data structures).
    *   Implement calculation logic for Slippage (Regression - applied to current orderbook depth), Fees (Rule-based), Market Impact (Almgren-Chriss - adapted for single market order simulation), and Maker/Taker Proportion (Logistic Regression).
    *   Ensure calculations are performed rapidly for each new tick.
*   **Performance:**
    *   The core data processing and calculation loop must have minimal latency to ensure processing speed exceeds the market data stream rate.
    *   Consider utilizing concurrent programming (threading/async I/O) to handle data reception independently from processing and UI updates, especially if using Python. C++ allows for more direct memory management and potentially faster execution.
*   **Model Implementation:**
    *   Implement the mathematical models for Slippage, Almgren-Chriss Market Impact, and Maker/Taker Proportion prediction accurately.
    *   Define and document the specific inputs and parameters used for each model instance within this simulator context (e.g., how volatility is used in AC, what features are used in regression models).
*   **User Interface:**
    *   Choose a suitable UI framework (e.g., PyQt, Tkinter in Python; Qt, wxWidgets in C++) capable of displaying real-time updates efficiently without blocking the core data processing loop.
    *   Implement the two-panel layout (Inputs/Outputs).
*   **Language Choice:**
    *   Implementation must be in either Python or C++. C++ is generally preferred for achieving the high-performance, low-latency requirements critical in real-time trading systems, but Python is acceptable as per the assignment. The chosen language will influence architectural decisions (e.g., concurrency model).
*   **Error Handling & Logging:**
    *   Implement robust error handling for network issues, data parsing errors, and calculation exceptions.
    *   Implement logging to aid debugging and monitoring (e.g., connection status, errors, warnings, potentially performance metrics).
*   **Documentation:**
    *   Provide internal code documentation (comments).
    *   Provide external documentation explaining model choices, parameters, calculation methodologies, and performance optimization approaches.

---

## 6. Implementation Roadmap

This roadmap outlines a suggested sequence for building the simulator, prioritizing core functionality and gradually adding complexity and polish. Given the 7-day assignment deadline, this reflects logical steps within that timeframe rather than a multi-release product plan.

**Phase 1: Foundation (Days 1-2)**

*   **Feature Focus:** 4.1 (Market Data Ingestion - Connection & Parsing), Basic UI Structure (4.9 - Panels), Placeholder Inputs/Outputs (4.2, 4.3).
*   **Technical Focus:** Choose language (Python/C++), set up development environment, implement WebSocket client connection, parse JSON data, establish basic internal orderbook data structure (even if simple initially), set up basic UI window with placeholders for inputs and outputs.
*   **Goal:** Successfully connect to the data feed, receive and parse messages, demonstrate data flow into the system, have a basic UI shell.

**Phase 2: Core Calculation Logic (Days 2-4)**

*   **Feature Focus:** 4.5 (Fees), 4.4 (Slippage Model - Initial Implementation), 4.8 (Maker/Taker Model - Initial Implementation), 4.6 (Almgren-Chriss - Initial Implementation), 4.7 (Net Cost), 4.2 (Input Logic), 4.3 (Output Logic), 4.9 (Latency Measurement).
*   **Technical Focus:** Implement core calculation functions for each required output metric. Connect input parameters to calculations. Implement latency measurement around the processing loop. Connect calculations to update UI output placeholders. Focus on getting the logic correct for one tick's data, less on real-time integration *yet*.
*   **Goal:** Calculations are implemented based on static or mock inputs derived from a single tick. Outputs can be manually verified. Latency measurement is in place.

**Phase 3: Real-time Integration & Basic Performance (Days 4-6)**

*   **Feature Focus:** 4.1 (Real-time Orderbook Update & Processing Speed), 4.3 (Real-time Output Updates), 4.10 (Core Performance, Error Handling, Logging).
*   **Technical Focus:** Integrate the calculation logic from Phase 2 with the real-time data stream from Phase 1. Ensure calculations are triggered efficiently upon receiving *each* new tick. Optimize the orderbook data structure and processing loop to achieve the "faster than stream" requirement. Implement basic error handling (e.g., try-except blocks, checking API responses) and logging for critical events. Ensure UI updates are non-blocking.
*   **Goal:** The simulator connects, processes real-time data, performs calculations on each tick, updates the UI in real-time, and maintains processing speed faster than the stream. Basic stability is achieved.

**Phase 4: Refinement, Documentation & Bonus (Days 6-7)**

*   **Feature Focus:** 4.10 (Clean Code, Documentation), All features (Refinement, Edge Cases), Bonus Section features (Performance Analysis, Optimization, Detailed Model Docs).
*   **Technical Focus:** Review and refactor code for maintainability. Add comprehensive code comments. Prepare external documentation covering models, algorithms, and methodology. Implement and document any chosen optimization techniques (memory, threading, etc.). Conduct and document performance benchmarking (Data processing latency, UI update latency, End-to-end latency). Test edge cases identified in Phase 2.
*   **Goal:** System is stable, meets core requirements, code is clean, documentation is complete, and bonus tasks are addressed. Prepare deliverables (Source Code, Documentation, Video).

---
```
