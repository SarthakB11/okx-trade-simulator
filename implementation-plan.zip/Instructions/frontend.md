```markdown
# Frontend Implementation Guide: High-Performance Trade Simulator UI

**Version: 1.0**
**Date: May 19, 2025**

## 1. Component Architecture

The frontend application can be structured using a component-based architecture, typical of modern JavaScript frameworks like React, Vue, or Angular. This approach promotes reusability, maintainability, and a clear separation of concerns.

The core components would likely be:

1.  **`App` (or equivalent Root Component):**
    *   Manages the overall application state.
    *   Orchestrates communication between the Input and Output panels and the API layer.
    *   Handles application-level concerns like loading states, errors, and the WebSocket connection lifecycle.

2.  **`InputPanel` Component:**
    *   Houses all the user input controls (dropdowns, text inputs).
    *   Manages the local state of the input parameters.
    *   Triggers an action (e.g., via a prop function) in the parent `App` component when the user initiates a simulation (e.g., clicks a "Start Simulation" button).

3.  **Input Control Components (e.g., `Dropdown`, `TextInput`):**
    *   Reusable components for specific input types (Exchange, Asset, Quantity, Volatility, Fee Tier).
    *   Handle user interaction and update their value state, propagating changes up to the `InputPanel`.

4.  **`OutputPanel` Component:**
    *   Displays the processed output values received from the backend.
    *   Receives the output data as props from the `App` component.

5.  **Output Display Components (e.g., `OutputField`):**
    *   Reusable components for displaying individual output values (Slippage, Fees, Market Impact, Net Cost, Maker/Taker, Internal Latency).
    *   Receive a label and a value as props and render them. Handle formatting (e.g., currency, percentages, latency units).

**Component Hierarchy Example (React-like):**

```
App
├── InputPanel
│   ├── Dropdown (Exchange)
│   ├── Dropdown (Spot Asset)
│   ├── TextInput (Quantity)
│   ├── TextInput (Volatility)
│   ├── Dropdown (Fee Tier)
│   └── Button (Start Simulation)
└── OutputPanel
    ├── OutputField (Expected Slippage)
    ├── OutputField (Expected Fees)
    ├── OutputField (Expected Market Impact)
    ├── OutputField (Net Cost)
    ├── OutputField (Maker/Taker Proportion)
    └── OutputField (Internal Latency)
```

## 2. State Management

Effective state management is crucial for handling both the user inputs and the real-time output updates.

*   **Input State:** The values entered by the user (Exchange, Asset, Quantity, etc.) should be stored. This state is primarily managed within the `InputPanel` component and lifted up to the `App` component when the simulation starts.
*   **Output State:** The calculated values received from the backend (Slippage, Fees, etc.) represent the dynamic output state. This state needs to be stored in the `App` component and passed down as props to the `OutputPanel` and its child `OutputField` components.
*   **Real-time Updates:** The WebSocket connection from the backend will push new output values frequently. The `App` component listens to these updates and *updates* its output state accordingly. This state change triggers re-renders in the `OutputPanel`, updating the UI in real-time.
*   **Loading/Simulation State:** A boolean flag (`isSimulationRunning`) can indicate when the simulation is active, potentially disabling input controls or showing a loading indicator.
*   **Error State:** Store any error messages received from the backend or related to WebSocket connection issues.

**State Management Approach:**

For a small to medium application like this, using the built-in state management capabilities of the chosen framework is often sufficient:

*   **React:** `useState` and `useReducer` hooks in functional components. `Context API` can be used to avoid prop drilling for output data if the structure becomes deeper (though unlikely here).
*   **Vue:** `data()` or `setup()` with `ref`/`reactive` for component local state. Pinia or Vuex for application-level state if complexity grows.
*   **Angular:** Component properties and services.

For this specific application, managing input state within `InputPanel` and lifting it up, while managing the real-time output state within `App` and passing it down, is a clean approach. The WebSocket logic resides in `App` or a dedicated service/hook.

## 3. UI Design

The UI design should prioritize clarity, usability, and efficient display of real-time data.

*   **Layout:** A simple two-panel layout (`InputPanel` on the left, `OutputPanel` on the right) is requested and effective. Use CSS Grid or Flexbox for responsive layout.
*   **Input Panel (`Left Panel`):**
    *   Clearly label each input field.
    *   Use appropriate controls: dropdowns for discrete choices (Exchange, Fee Tier, potentially Asset if a fixed list is loaded), text inputs for numerical values (Quantity, Volatility).
    *   Include validation where necessary (e.g., ensuring Quantity is a positive number).
    *   A prominent button ("Start Simulation", "Run") to initiate the process.
*   **Output Panel (`Right Panel`):**
    *   Clearly label each output value.
    *   Display values prominently. Use monospace font for numerical outputs to help align values as they update.
    *   Consider using units where appropriate (e.g., $, %, ms).
    *   Highlight the Net Cost as it's a key summary metric.
    *   Ensure values update smoothly with incoming ticks. Avoid flickering if possible (e.g., by only updating the DOM when the value actually changes, or using efficient rendering techniques).
    *   Display the Internal Latency to provide feedback on the backend's processing speed.
*   **Responsiveness:** While not explicitly requested, consider how the layout adapts to different screen sizes (e.g., stacking panels vertically on smaller screens).
*   **Visual Feedback:** Show loading indicators or disable inputs while the simulation is starting or if there are connection issues. Display error messages clearly.

## 4. API Integration

The frontend needs to communicate with the backend service (Python/C++ application) to:

1.  Send the user-defined input parameters to start the simulation.
2.  Receive real-time output updates (Slippage, Fees, etc.) based on the backend processing the WebSocket data.

**Integration Strategy:**

*   **Initiating Simulation:** Use a standard HTTP request (e.g., POST or PUT) to send the initial configuration (Exchange, Asset, Quantity, etc.) to a backend endpoint (e.g., `/api/simulate/start`). The backend would then establish its WebSocket connection to the exchange, set up the simulation, and prepare to send results.
*   **Receiving Real-time Updates:** The backend should establish a *separate* WebSocket connection *to the frontend*. This is the most efficient way to push frequent, low-latency updates. The frontend `App` component (or a dedicated service/hook) will connect to this frontend-facing WebSocket endpoint (e.g., `ws://localhost:8080/results` or similar).
*   **Data Format:** Ensure both frontend and backend agree on the data format, likely JSON, for both HTTP requests and WebSocket messages.
*   **Error Handling:** Implement error handling for HTTP requests (e.g., if the backend fails to start the simulation) and the WebSocket connection (connection errors, message parsing errors). Display these errors to the user.

**Backend Endpoints (Example):**

*   `POST /api/simulate/start`: Receives input parameters body (JSON). Returns success/failure message, maybe a unique simulation ID if needed.
*   `GET /api/simulate/stop`: To stop the simulation (optional, but good practice).
*   `WS /api/simulate/results`: WebSocket endpoint where the backend pushes real-time JSON messages containing the output parameters.

**Frontend Workflow:**

1.  User fills in inputs and clicks "Start Simulation".
2.  Frontend (`App` component) gathers input state.
3.  Frontend sends a POST request to `/api/simulate/start` with the inputs.
4.  Upon successful response from the POST request, the frontend opens a WebSocket connection to `/api/simulate/results`.
5.  The backend processes exchange data and sends messages over this WebSocket.
6.  The frontend receives WebSocket messages, updates the output state in the `App` component, triggering UI re-renders in the `OutputPanel`.
7.  Handle WebSocket closure (expected or unexpected) and display connection status.

## 5. Testing Approach

A layered testing approach helps ensure the quality and reliability of the frontend application.

1.  **Unit Tests:**
    *   Focus: Individual components in isolation (e.g., `InputPanel`, `OutputPanel`, `Dropdown`, `OutputField`).
    *   Purpose: Verify rendering correctness, handle user interactions (e.g., dropdown selection updates local state), prop handling, and simple logic within components.
    *   Tools: Jest, React Testing Library, Vue Test Utils, Karma/Jasmine (for Angular).
    *   Examples: Test that `InputPanel` renders all required input fields. Test that selecting an option in `Dropdown` calls the `onChange` prop with the correct value. Test that `OutputField` displays the label and value correctly formatted.

2.  **Integration Tests:**
    *   Focus: Interaction between multiple components or between components and services (like the API layer).
    *   Purpose: Verify that components work together as expected (e.g., `InputPanel` passing data up to `App`, `App` passing data down to `OutputPanel`). Test the frontend's API layer (mocking backend responses).
    *   Tools: Same as unit tests, but testing across component boundaries.
    *   Examples: Test that clicking the "Start Simulation" button in `InputPanel` triggers a function in `App` with the current input values. Test that when `App` receives new data from a mocked WebSocket service, the `OutputPanel` updates with the new values.

3.  **End-to-End (E2E) Tests:**
    *   Focus: Simulating a user's journey through the entire application in a real browser environment.
    *   Purpose: Verify that the complete system, from user input to backend communication and UI output, works correctly. This is the closest to testing the actual user experience.
    *   Tools: Cypress, Playwright, Selenium.
    *   Examples: Open the application, fill in all input fields, click "Start Simulation", verify that the output panel appears and that the output values update over time (might require mocking the backend WebSocket to provide a controlled stream of data for deterministic tests).

4.  **Performance Testing (Related to Bonus):**
    *   Focus: Measuring UI update latency and overall responsiveness under a high rate of data updates.
    *   Purpose: Identify rendering bottlenecks and ensure the UI can keep up with the real-time data stream without becoming sluggish or unresponsive.
    *   Tools: Browser developer tools (Performance tab), dedicated performance testing libraries.
    *   Methodology: Measure the time between receiving a WebSocket message in the frontend and the UI reflecting that update.

## 6. Code Examples

Here are simplified React-like code examples illustrating key frontend concepts.

**Assumptions:**

*   Using React functional components and Hooks.
*   Backend provides a REST endpoint `/api/simulate/start` (POST) and a WebSocket endpoint `ws://localhost:3001/results` for real-time updates.
*   Basic styling omitted for brevity.

**1. `App` Component (Handling State and API Integration)**

```jsx
import React, { useState, useEffect, useRef } from 'react';
import InputPanel from './InputPanel';
import OutputPanel from './OutputPanel';

// Define initial state for outputs
const initialOutputs = {
  expectedSlippage: 'N/A',
  expectedFees: 'N/A',
  expectedMarketImpact: 'N/A',
  netCost: 'N/A',
  makerTakerProportion: 'N/A',
  internalLatency: 'N/A',
};

function App() {
  const [inputParams, setInputParams] = useState({
    exchange: 'OKX', // Default or loaded from backend
    spotAsset: 'BTC-USDT', // Default or loaded from backend
    orderType: 'market', // Fixed for this assignment
    quantity: 100, // USD equivalent
    volatility: 0.02, // Example value
    feeTier: 'Tier 1', // Example value
  });

  const [outputValues, setOutputValues] = useState(initialOutputs);
  const [isSimulationRunning, setIsSimulationRunning] = useState(false);
  const [error, setError] = useState(null);

  // Ref for the WebSocket connection
  const wsRef = useRef(null);

  // Function to start the simulation via HTTP POST
  const startSimulation = async () => {
    setIsSimulationRunning(true);
    setError(null);
    setOutputValues(initialOutputs); // Reset outputs

    try {
      const response = await fetch('/api/simulate/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(inputParams),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      // Assuming backend responds with success and potentially config for WS
      console.log('Simulation start request successful.');

      // === Establish WebSocket connection for results ===
      // Close any existing connection first
      if (wsRef.current) {
        wsRef.current.close();
      }

      const ws = new WebSocket('ws://localhost:3001/results');

      ws.onopen = () => {
        console.log('WebSocket connection for results opened.');
        // Maybe send a message to backend indicating FE is ready for results?
      };

      ws.onmessage = (event) => {
        // Process real-time updates from backend
        try {
          const data = JSON.parse(event.data);
          // Update output state with the new data from the tick
          // Assume backend sends an object matching the outputValues structure
          setOutputValues(prevOutputs => ({ ...prevOutputs, ...data }));
        } catch (err) {
          console.error('Error parsing WebSocket message:', err);
        }
      };

      ws.onerror = (err) => {
        console.error('WebSocket error:', err);
        setError('WebSocket error. Simulation updates may be interrupted.');
        setIsSimulationRunning(false); // Assume error stops updates
      };

      ws.onclose = (event) => {
        console.log('WebSocket connection closed:', event.code, event.reason);
        // Handle closure - maybe simulation finished, or error
        if (!event.wasClean) {
             setError('WebSocket connection closed unexpectedly.');
        }
        setIsSimulationRunning(false); // Simulation effectively stopped from FE perspective
      };

      wsRef.current = ws; // Store the WebSocket instance

    } catch (err) {
      console.error('Failed to start simulation:', err);
      setError(`Error starting simulation: ${err.message}`);
      setIsSimulationRunning(false);
    }
  };

  // Effect to close WebSocket on component unmount
  useEffect(() => {
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  return (
    <div style={{ display: 'flex', padding: '20px' }}>
      <div style={{ flex: 1, marginRight: '20px' }}>
        <InputPanel
          params={inputParams}
          onParamsChange={setInputParams}
          onStartSimulation={startSimulation}
          isSimulationRunning={isSimulationRunning}
        />
        {error && <div style={{ color: 'red', marginTop: '10px' }}>Error: {error}</div>}
      </div>
      <div style={{ flex: 1 }}>
        <OutputPanel outputs={outputValues} />
      </div>
    </div>
  );
}

export default App;
```

**2. `InputPanel` Component**

```jsx
import React from 'react';

// Dummy data for dropdowns - in a real app, this might come from backend
const exchanges = ['OKX']; // Only OKX for this assignment
const assets = ['BTC-USDT', 'ETH-USDT', 'SOL-USDT']; // Example assets
const feeTiers = ['Tier 1', 'Tier 2', 'Tier 3']; // Example tiers

function InputPanel({ params, onParamsChange, onStartSimulation, isSimulationRunning }) {

  const handleChange = (e) => {
    const { name, value } = e.target;
    onParamsChange({ ...params, [name]: value });
  };

  // Basic validation check
  const isValid = params.quantity > 0 && params.volatility >= 0;

  return (
    <div>
      <h2>Input Parameters</h2>
      <div>
        <label>Exchange:</label>
        <select name="exchange" value={params.exchange} onChange={handleChange} disabled={isSimulationRunning}>
          {exchanges.map(ex => <option key={ex} value={ex}>{ex}</option>)}
        </select>
      </div>
      <div>
        <label>Spot Asset:</label>
         {/* This could be a dropdown if fetching from backend, text input for now */}
        <select name="spotAsset" value={params.spotAsset} onChange={handleChange} disabled={isSimulationRunning}>
           {assets.map(asset => <option key={asset} value={asset}>{asset}</option>)}
        </select>
      </div>
      <div>
        <label>Order Type:</label>
        {/* Fixed for this assignment */}
        <input type="text" name="orderType" value={params.orderType} readOnly disabled />
      </div>
      <div>
        <label>Quantity (~USD):</label>
        <input
          type="number"
          name="quantity"
          value={params.quantity}
          onChange={handleChange}
          disabled={isSimulationRunning}
          min="0.01" // Add constraints
        />
      </div>
       <div>
        <label>Volatility:</label>
        <input
          type="number"
          name="volatility"
          value={params.volatility}
          onChange={handleChange}
          disabled={isSimulationRunning}
          step="0.001" // Allow decimal input
          min="0"
        />
      </div>
      <div>
        <label>Fee Tier:</label>
        <select name="feeTier" value={params.feeTier} onChange={handleChange} disabled={isSimulationRunning}>
           {feeTiers.map(tier => <option key={tier} value={tier}>{tier}</option>)}
        </select>
      </div>
      <div style={{ marginTop: '20px' }}>
        <button onClick={onStartSimulation} disabled={isSimulationRunning || !isValid}>
          {isSimulationRunning ? 'Simulation Running...' : 'Start Simulation'}
        </button>
      </div>
    </div>
  );
}

export default InputPanel;
```

**3. `OutputPanel` Component**

```jsx
import React from 'react';
import OutputField from './OutputField'; // Assume OutputField component exists

function OutputPanel({ outputs }) {
  return (
    <div>
      <h2>Processed Output Values</h2>
      <OutputField label="Expected Slippage" value={outputs.expectedSlippage} unit="%" />
      <OutputField label="Expected Fees" value={outputs.expectedFees} unit="$" />
      <OutputField label="Expected Market Impact" value={outputs.expectedMarketImpact} unit="$" />
      <OutputField label="Net Cost" value={outputs.netCost} unit="$" highlight={true} /> {/* Highlight Net Cost */}
      <OutputField label="Maker/Taker Proportion" value={outputs.makerTakerProportion} unit="" /> {/* Might be ratio/percentage */}
      <OutputField label="Internal Latency (per tick)" value={outputs.internalLatency} unit="ms" />
    </div>
  );
}

export default OutputPanel;
```

**4. `OutputField` Component**

```jsx
import React from 'react';

// Helper to format numbers - could be more sophisticated
const formatValue = (value, unit, highlight) => {
  if (value === 'N/A') return value;

  let formatted = parseFloat(value).toFixed(4); // Example formatting
  if (unit === '$') formatted = `$${formatted}`;
  if (unit === '%') formatted = `${formatted}%`;
  if (unit === 'ms') formatted = `${formatted} ms`;

  return formatted;
};


function OutputField({ label, value, unit = '', highlight = false }) {
  const valueStyle = {
    fontWeight: highlight ? 'bold' : 'normal',
    color: highlight ? 'green' : 'inherit', // Example highlighting
    fontFamily: 'monospace', // Helps align updating numbers
    marginLeft: '10px',
  };

  return (
    <div style={{ margin: '10px 0' }}>
      <strong>{label}:</strong>
      <span style={valueStyle}>
        {formatValue(value, unit, highlight)}
      </span>
    </div>
  );
}

export default OutputField;
```

These examples provide a basic structure. Further development would involve more robust input validation, better error display, potentially charting for performance metrics, and more sophisticated styling. The key is that the frontend acts as the presentation layer, sending user inputs to the backend and displaying the real-time results pushed from the backend's calculations.
```
