```markdown
# Trade Simulator Requirements Document

**Version:** 1.0
**Date:** May 19, 2025

## 1. Project Overview

The objective of this project is to develop a high-performance Trade Simulator. This simulator will leverage real-time, Level 2 (L2) orderbook data streamed from a provided WebSocket endpoint for cryptocurrency exchanges. The primary goal is to estimate transaction costs and market impact for a theoretical market order execution.

The simulator aims to provide users (e.g., quantitative analysts or traders) with insight into potential costs before executing a trade of a specified size on a specific exchange and asset. By processing real-time market depth data and applying established financial models, the system will calculate expected slippage, fees, market impact, and total net cost, along with estimating the proportion of the order likely filled as maker vs. taker trades. Performance metrics, such as internal processing latency, will also be tracked.

The project emphasizes real-time data processing efficiency, accurate model implementation, and a clean, maintainable codebase with robust error handling.

## 2. Functional Requirements

This section details the key features and capabilities of the Trade Simulator system.

| ID      | Feature                                   | Description                                                                                                | Acceptance Criteria                                                                                                                               |
| :------ | :---------------------------------------- | :--------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------ |
| FR-UI-1 | User Interface (UI)                       | The system shall provide a graphical user interface.                                                       | UI application window opens successfully and displays distinct input and output sections.                                                           |
| FR-UI-2 | Input Panel                               | The UI shall have a distinct left-hand panel for entering trade simulation parameters.                     | The left panel is clearly separated and contains input fields/controls for all required parameters.                                             |
| FR-UI-3 | Output Panel                              | The UI shall have a distinct right-hand panel for displaying processed output values.                      | The right panel is clearly separated and contains display areas for all calculated output values.                                                 |
| FR-IN-1 | Input: Exchange Selection                 | The system shall allow specifying the target exchange.                                                     | Input field/control exists for 'Exchange'. Default or selectable value shall be "OKX".                                                            |
| FR-IN-2 | Input: Spot Asset Selection               | The system shall allow specifying the spot asset for the trade simulation.                                 | Input field/control exists for 'Spot Asset'. The user can specify any asset available on the selected exchange (e.g., BTC-USDT, ETH-USDT).          |
| FR-IN-3 | Input: Order Type Selection               | The system shall allow specifying the order type for simulation.                                           | Input field/control exists for 'Order Type'. The selectable value shall be restricted to "market".                                                |
| FR-IN-4 | Input: Quantity                           | The system shall allow specifying the trade quantity, expressed in USD equivalent.                           | Input field/control exists for 'Quantity'. The user can input a value, expected to be around "~100 USD equivalent". System handles numerical input. |
| FR-IN-5 | Input: Volatility                         | The system shall allow specifying the market volatility parameter.                                         | Input field/control exists for 'Volatility'. Input accepts a numerical value representing volatility (e.g., annualised percentage).               |
| FR-IN-6 | Input: Fee Tier                           | The system shall allow specifying the user's fee tier level.                                               | Input field/control exists for 'Fee Tier'. Input represents a user's fee level as per exchange documentation.                                   |
| FR-DATA-1 | WebSocket Connection                    | The system shall connect to a specified WebSocket endpoint to receive real-time market data.               | System successfully establishes a stable connection to `wss://ws.gomarket-cpp.goquant.io/ws/l2-orderbook/okx/BTC-USDT-SWAP`.                    |
| FR-DATA-2 | Real-time Data Processing                 | The system shall process incoming L2 orderbook data from the WebSocket stream in real-time.                | For each received message (tick) conforming to the specified format, the system triggers processing logic.                                    |
| FR-DATA-3 | L2 Orderbook Data Handling                | The system shall parse and utilize the L2 orderbook data (bids and asks with prices and volumes).          | The system correctly extracts `timestamp`, `exchange`, `symbol`, `asks` (price, volume pairs), and `bids` (price, volume pairs) from messages. |
| FR-CALC-1 | Expected Slippage Calculation             | The system shall estimate expected slippage for the market order.                                          | Slippage is calculated using a linear or quantile regression model based on observed market data depth. Output field displays the calculated value. |
| FR-CALC-2 | Expected Fees Calculation                 | The system shall estimate expected transaction fees.                                                         | Fees are calculated using a rule-based model based on the specified Fee Tier, Order Type (market), and the calculated execution price/quantity. Output field displays the calculated value. |
| FR-CALC-3 | Expected Market Impact Calculation        | The system shall estimate the expected market impact of the trade.                                         | Market impact is calculated using the Almgren-Chriss model. Output field displays the calculated value.                                          |
| FR-CALC-4 | Net Cost Calculation                      | The system shall calculate the total estimated cost of the trade.                                          | Net Cost is calculated as the sum of Expected Slippage, Expected Fees, and Expected Market Impact. Output field displays the calculated value.    |
| FR-CALC-5 | Maker/Taker Proportion Prediction         | The system shall predict the proportion of the market order likely filled as maker vs. taker.              | Maker/Taker proportion is predicted using a logistic regression model. Output field displays the calculated proportion (e.g., Taker %).             |
| FR-CALC-6 | Internal Latency Measurement              | The system shall measure the time taken to process each incoming data tick and update outputs.             | The system records and displays the processing time (latency) per tick. Output field displays the measured value (e.g., in milliseconds or microseconds). |
| FR-UPDATE-1 | Real-time Output Update                   | The UI output panel shall update with new calculated values upon processing each incoming data tick.         | All output parameters (Slippage, Fees, Market Impact, Net Cost, Maker/Taker, Internal Latency) are refreshed in the UI with the latest calculations after each tick. |
| FR-MODEL-1 | Model Implementation                      | Required models (Regression for Slippage, Rule-based Fees, Almgren-Chriss for Market Impact, Logistic Regression for Maker/Taker) shall be implemented. | Each model is correctly implemented based on financial/statistical principles and uses the available input parameters and real-time market data. |

## 3. Non-Functional Requirements

This section outlines the quality attributes and technical constraints of the Trade Simulator.

| ID         | Requirement           | Description                                                                                                                               | Acceptance Criteria                                                                                                                               |
| :--------- | :-------------------- | :---------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------ |
| NFR-PERF-1 | Performance - Speed   | The system shall process incoming data ticks and update outputs faster than the data stream is received.                                | Average processing time per tick is consistently less than the average interval between ticks received from the WebSocket endpoint.                 |
| NFR-PERF-2 | Real-time Processing  | Calculations and UI updates shall be performed in real-time based on the incoming data stream.                                            | Output values reflect the market state represented by the most recently processed data tick with minimal perceivable delay.                       |
| NFR-TECH-1 | Implementation Language | The system shall be implemented using either Python or C++.                                                                               | The entire codebase is written exclusively in either Python or C++.                                                                               |
| NFR-TECH-2 | Error Handling        | The system shall include proper error handling for issues such as WebSocket connection failures, data parsing errors, or calculation errors. | Critical errors (e.g., connection loss) are logged and/or reported to the user without crashing the application. Data errors are handled gracefully (e.g., logging, skipping tick). |
| NFR-TECH-3 | Logging               | The system shall implement logging for significant events, errors, and potentially performance metrics.                                   | A log file or console output captures relevant system events, warnings, and errors.                                                               |
| NFR-TECH-4 | Code Architecture     | The codebase shall be clean, maintainable, and follow good software design principles.                                                    | Code is modular, well-structured, follows consistent coding standards, and is easy to understand and extend.                                        |
| NFR-DOC-1  | Model Documentation   | Documentation explaining the implementation details of the financial/statistical models used shall be included.                             | Separate documentation or inline comments explain the specific regression model chosen for slippage, the Almgren-Chriss market impact calculation, the rule-based fee logic, and the logistic regression model for maker/taker. |
| NFR-BONUS-1 | (Bonus) Performance Analysis | If attempting the bonus, the system shall measure and document specific performance metrics.                                            | Data processing latency, UI update latency, and end-to-end simulation loop latency are measured and reported.                                      |
| NFR-BONUS-2 | (Bonus) Optimization  | If attempting the bonus, optimization techniques for performance shall be implemented and justified.                                      | Specific techniques for memory management, network communication, data structure selection, thread management (if used), and model efficiency are applied and explained. |

## 4. Dependencies and Constraints

This section lists external dependencies and limitations affecting the project implementation.

| Type        | Item                        | Description                                                                                                |
| :---------- | :-------------------------- | :--------------------------------------------------------------------------------------------------------- |
| **Dependency** | WebSocket Library           | A suitable library for establishing and managing WebSocket connections (e.g., `websockets` in Python, `Boost.Asio` or similar in C++). |
| **Dependency** | Numerical/Statistical Libraries | Libraries required for model implementation (e.g., NumPy, SciPy, scikit-learn in Python; Eigen, BLAS/LAPACK, or similar in C++). |
| **Dependency** | UI Framework                | A library or framework for building the graphical user interface (e.g., Tkinter, PyQt/PySide in Python; Qt, MFC, or similar in C++). |
| **Dependency** | VPN Access                  | Access to a VPN is required to connect to the OKX market data endpoint.                                    |
| **Dependency** | Internet Connectivity       | Stable internet connection is required to receive real-time data.                                          |
| **Constraint** | Implementation Language     | Must be implemented in either Python or C++.                                                               |
| **Constraint** | WebSocket Endpoint          | Must connect to the specific URL: `wss://ws.gomarket-cpp.goquant.io/ws/l2-orderbook/okx/BTC-USDT-SWAP`.     |
| **Constraint** | Data Format                 | Must adhere to the specified JSON format for processing incoming L2 orderbook data.                        |
| **Constraint** | Model Usage                 | Specific models (Almgren-Chriss, Regression for Slippage, Logistic Regression for Maker/Taker, Rule-based Fees) must be used as specified. |
| **Constraint** | OKX Public Data           | Data is accessed via public API endpoint, no account creation is required or permitted for this specific task. |

## 5. Risk Assessment

This section identifies potential risks that could impact the project and proposes mitigation strategies.

| Risk ID | Risk Description                     | Likelihood | Impact | Mitigation Strategy                                                                                                                            |
| :------ | :----------------------------------- | :--------- | :----- | :--------------------------------------------------------------------------------------------------------------------------------------------- |
| R-DATA-1 | WebSocket Connection Issues          | Medium     | High   | Implement robust error handling for connection errors, automatic reconnect logic (with backoff), and clear user notification of status.          |
| R-DATA-2 | Data Stream Lag or Disruption        | Medium     | High   | Implement checks for stale data; log data arrival times to monitor stream health; potentially queue incoming data to smooth processing peaks.    |
| R-PERF-1 | Processing Cannot Keep Up            | Medium     | High   | Profile code to identify bottlenecks; optimize data structures and algorithms; consider concurrency/threading (especially in C++) if necessary. |
| R-PERF-2 | UI Lag/Unresponsiveness            | Low        | Medium | Decouple data processing from UI updates (e.g., run processing in a separate thread/process); ensure UI updates are efficient.                 |
| R-MODEL-1 | Model Accuracy/Interpretation        | Medium     | High   | Carefully review and validate model implementations against standard formulas; document assumptions made; clearly explain model limitations.   |
| R-MODEL-2 | Difficulty Implementing Models       | Low        | Medium | Utilize established libraries where available; break down complex models (like Almgren-Chriss) into smaller, manageable components.          |
| R-TECH-1 | VPN Connectivity Problems            | Low        | Medium | Verify VPN setup works correctly during initial setup; ensure VPN is stable during testing.                                                      |
| R-SCOPE-1 | Underestimating Complexity           | Low        | Medium | Allocate sufficient time for complex parts like real-time processing and model implementation; phase development if needed.                   |
| R-ENV-1 | Development Environment Setup Issues | Low        | Low    | Document detailed setup steps; use standard/well-supported libraries and tools; allocate time for initial environment configuration.             |
```
