```markdown
# Trade Simulator System Flow Document

## Document Header
Version: 1.0
Date: May 19, 2025

## System Overview

This document outlines the system architecture and key flows for the High-Performance Trade Simulator. The simulator is designed to estimate transaction costs and market impact for a potential trade by leveraging real-time, Level 2 (L2) orderbook data received via a WebSocket connection.

The system consists of the following core components:

1.  **User Interface (UI):** Provides input fields for simulation parameters and displays calculated output metrics in real-time.
2.  **Input Handling Module:** Validates and processes user-provided simulation parameters (Exchange, Asset, Quantity, Order Type, Volatility, Fee Tier).
3.  **WebSocket Connector:** Manages the connection to the L2 orderbook WebSocket endpoint, handling connection attempts, reconnections, and raw data reception.
4.  **Real-time Data Processor:** Receives raw orderbook data from the WebSocket Connector, parses it, and prepares it for model consumption. It's also responsible for coordinating the simulation loop and measuring internal latency.
5.  **Model Engine:** Houses the core simulation logic, including:
    *   Rule-based Fee Model
    *   Regression Models (Linear/Quantile) for Slippage Estimation
    *   Almgren-Chriss Model for Market Impact Calculation
    *   Logistic Regression Model for Maker/Taker Proportion Prediction
6.  **Output Display Module:** Formats and updates the calculated output parameters (Slippage, Fees, Market Impact, Net Cost, Maker/Taker Proportion, Internal Latency) in the UI.

The system is designed to process market data ticks faster than they are received to maintain a real-time simulation state and minimize processing backlog. Implementation will be in either Python or C++.

## User Workflows

The primary user workflow involves configuring simulation parameters and observing real-time cost and impact estimations based on live market data.

**Workflow: Configure and Observe Simulation**

1.  **User Input:** The user interacts with the UI's left panel to select/enter simulation parameters:
    *   Exchange (e.g., OKX)
    *   Spot Asset (e.g., BTC-USDT)
    *   Order Type (Market)
    *   Quantity (e.g., ~100 USD equivalent)
    *   Volatility (Market parameter)
    *   Fee Tier (based on exchange docs)
2.  **System Initialization:** Upon setting valid parameters (or clicking a 'Start' button), the system validates inputs. If valid, the system initializes the WebSocket Connector and attempts to connect to the specified L2 orderbook endpoint for the chosen asset (e.g., `wss://ws.gomarket-cpp.goquant.io/ws/l2-orderbook/okx/BTC-USDT-SWAP`).
3.  **Real-time Data Stream:** The WebSocket Connector establishes and maintains the connection, streaming L2 orderbook data ticks.
4.  **Processing and Calculation:** The Real-time Data Processor receives ticks, updates the internal representation of the orderbook, and triggers the Model Engine to recalculate all output metrics based on the latest market state and user inputs. Internal processing latency per tick is measured.
5.  **UI Update:** The Output Display Module receives the newly calculated metrics from the Real-time Data Processor and updates the UI's right panel in real-time.
6.  **User Observation:** The user observes the dynamically updating output parameters (Slippage, Fees, Market Impact, Net Cost, Maker/Taker, Latency) as new market data arrives and is processed.
7.  **Simulation Control (Optional):** The user may have an option to stop or pause the simulation, which would trigger the system to close the WebSocket connection and cease processing.

```mermaid
graph TD
    A[User] --> B{Set Input Parameters};
    B --> C{Validate & Init System};
    C -- If Valid --> D(Connect to WebSocket);
    D --> E[Receive Orderbook Tick];
    E --> F{Process Tick & Calculate Metrics};
    F --> G[Update UI Outputs];
    G --> E;
    A --> H{Observe Real-time Outputs};
    H -- Continuously --> G;
    G -- Data Updates --> H;
    B -- If Invalid --> I[Display Input Error];
    D -- Connection Error --> J[Handle WS Error & Reconnect];
    F -- Processing Error --> K[Log & Handle Processing Error];
```

*Diagram Explanation: The user sets parameters which initialize the system. The system connects to the WebSocket and enters a loop where it receives ticks, processes them to calculate outputs, and updates the UI for the user to observe in real-time. Error paths for invalid input, WebSocket issues, and processing errors are indicated.*

## Data Flows

Data flows through the system originating from two main sources: User Input and the Market Data WebSocket.

1.  **User Input Data Flow:**
    *   **Source:** UI (Input Panel)
    *   **Path:** User input values -> Input Handling Module -> Real-time Data Processor (for simulation configuration)
    *   **Description:** User-defined parameters like asset, quantity, etc., are captured by the UI, validated by the Input Handler, and used by the main processor to configure the simulation and models.

2.  **Market Data Flow:**
    *   **Source:** External WebSocket Endpoint (`wss://ws.gomarket-cpp.goquant.io/ws/l2-orderbook/...`)
    *   **Path:** Raw JSON L2 Data -> WebSocket Connector -> Real-time Data Processor -> Model Engine -> Real-time Data Processor -> Output Display Module -> UI (Output Panel)
    *   **Description:** Real-time L2 orderbook ticks are received by the WebSocket Connector, parsed and structured by the Real-time Data Processor. This processed data is fed to the Model Engine for calculation of slippage, impact, fees, etc. The calculated results are then sent back to the Processor, formatted by the Output Display Module, and presented in the UI. This forms the core real-time processing loop.

3.  **Calculated Output Data Flow:**
    *   **Source:** Model Engine
    *   **Path:** Calculated Metrics -> Real-time Data Processor -> Output Display Module -> UI (Output Panel)
    *   **Description:** The output values (Slippage, Fees, Market Impact, Net Cost, Maker/Taker, Internal Latency) computed by the Model Engine and the Real-time Data Processor are passed through the Output Display Module for formatting and then rendered in the UI for the user.

```mermaid
graph LR
    A[UI Input Panel] --> B(Input Handling);
    B --> C{Real-time Data Processor};
    D[External WebSocket Endpoint] --> E(WebSocket Connector);
    E -- Raw L2 Data --> C;
    C -- Processed Orderbook --> F(Model Engine);
    F -- Calculated Metrics --> C;
    C -- Formatted Outputs --> G(Output Display);
    G --> H[UI Output Panel];

    subgraph Data Sources
        A
        D
    end

    subgraph Processing & Modeling
        B
        C
        E
        F
        G
    end

    subgraph Data Destination
        H
    end
```

*Diagram Explanation: Shows the movement of data from user inputs and the external WebSocket endpoint through the system components (Input Handling, WebSocket Connector, Real-time Data Processor, Model Engine, Output Display) to the UI output panel.*

## Error Handling

Robust error handling is critical for a real-time system. The following strategies will be employed:

1.  **Input Validation:** User inputs in the UI will be validated before initializing the simulation or processing data. Invalid inputs will trigger user-friendly error messages in the UI.
2.  **WebSocket Connection Management:**
    *   Implement retry mechanisms for initial connection failures.
    *   Listen for connection closure events and attempt to reconnect with exponential backoff.
    *   Handle potential network issues gracefully, perhaps displaying a "Connecting..." or "Disconnected" status.
3.  **Data Parsing Errors:** Errors encountered while parsing incoming WebSocket messages (e.g., unexpected format) will be logged, and the erroneous message will be skipped. The system should ideally be resilient to malformed individual messages without crashing.
4.  **Model Calculation Errors:** Models (regression, Almgren-Chriss) might encounter errors (e.g., numerical instability, division by zero if orderbook is empty or illiquid in a specific spot). These errors should be caught, logged, and potentially result in displaying an "Error" or "N/A" value for the specific output parameter in the UI, without halting the entire simulation.
5.  **Performance Monitoring:** Internal latency per tick processing will be measured. If processing consistently lags behind the incoming data stream, this will be logged as a potential performance bottleneck requiring optimization. While not strictly an "error", prolonged lag is a critical operational issue.
6.  **Logging:** Comprehensive logging will be implemented across all components to record errors, warnings, and key events (e.g., connection status changes, processing latencies). This aids debugging and performance analysis.
7.  **UI Feedback:** Error conditions (e.g., invalid input, WebSocket disconnect, model calculation failure) will be communicated to the user via status indicators or messages in the UI.

## Security Flows

Given the nature of this assignment accessing public market data, the security considerations for *this specific component* are minimal compared to a system handling private user data or executing trades.

1.  **Data Source Authentication/Authorization:** The assignment explicitly states no account is required for accessing the public WebSocket data. Therefore, there are no specific authentication or authorization flows needed for the WebSocket connection itself. The VPN requirement mentioned in the prompt is an external network access requirement, not an internal application security flow.
2.  **Data Integrity:** While the data is public, the system should perform basic validation of the incoming data format to prevent crashes due to malformed messages. This is more data validation than security integrity in the classical sense, but it contributes to the system's robustness against potentially unexpected input.
3.  **Input Sanitization:** Although the inputs are simple parameters (numeric values, predefined strings), basic sanitization should be applied to prevent potential injection issues if the system were extended in the future to handle more complex inputs or interact with other services based on user input. For this assignment's scope, validation of format and range is sufficient.
4.  **System Environment:** Standard secure coding practices for Python/C++ should be followed. However, since this is a client-side simulation tool accessing public data, the primary security focus is on the execution environment (e.g., ensuring the host machine is secure), rather than complex internal application security flows like user authentication or access control.

In summary, for this specific assignment, the security flows are primarily focused on validating the format of incoming public data and relying on external measures (like VPN) for network access where required by the data provider. Robust authentication/authorization mechanisms typical of trading systems handling sensitive data or execution are not part of this component's scope.
```
